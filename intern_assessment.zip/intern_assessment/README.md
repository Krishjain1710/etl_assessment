# ETL Intern Assessment - 3 Days Challenge
================================================

## Assessment Overview

Assessment Duration: 3 Days (15 NOV - 17 NOV)

Convert the provided telecom_etl_pipeline.sh file to a Python script, then create an Airflow DAG that runs daily at 12:00 PM.

## Getting Started

To run the telecom_etl_pipeline.sh file using following command: 
bash telecom_etl_pipeline.sh 2>&1